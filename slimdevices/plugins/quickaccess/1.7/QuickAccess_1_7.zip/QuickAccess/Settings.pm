package Plugins::QuickAccess::Settings;

# SlimServer Copyright (C) 2001-2006 Slim Devices Inc.
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.

use strict;
use base qw(Slim::Web::Settings);

use Slim::Utils::Strings qw(string);
use Slim::Utils::Log;
use Slim::Utils::Prefs;

# ----------------------------------------------------------------------------
# References to other classes
my $classPlugin		= undef;

# ----------------------------------------------------------------------------
my $log = Slim::Utils::Log->addLogCategory({
	'category'     => 'plugin.quickaccess',
	'defaultLevel' => 'OFF',
	'description'  => 'PLUGIN_QUICKACCESS_MODULE_NAME',
});

# ----------------------------------------------------------------------------
my $prefs = preferences('plugin.quickaccess');

$prefs->migrateClient( 1, sub {
	my( $clientprefs, $client) = @_;

	$clientprefs->set('button',Slim::Utils::Prefs::OldPrefs->clientGet($client,'plugin_quickaccess_button'));
	1;
});

# ----------------------------------------------------------------------------
# Define own constructor
# - to save references to Plugin.pm
# ----------------------------------------------------------------------------
sub new {
	my $class = shift;

	$classPlugin = shift;

	$log->debug( "*** QuickAccess::Settings::new() " . $classPlugin . "\n");

	$class->SUPER::new();

	return $class;
}

# ----------------------------------------------------------------------------
# Name in the settings dropdown
# ----------------------------------------------------------------------------
sub name {
	return 'PLUGIN_QUICKACCESS_MODULE_NAME';
}

# ----------------------------------------------------------------------------
# Webpage served for settings
# ----------------------------------------------------------------------------
sub page {
	return 'plugins/QuickAccess/setup_index.html';
}

# ----------------------------------------------------------------------------
# Settings are per player
# ----------------------------------------------------------------------------
sub needsClient {
	return 1;
}

my @dummy = ();


# ----------------------------------------------------------------------------
# Handler for settings for the four events (on,off,volup,voldown) and more
# ----------------------------------------------------------------------------
sub handler {
	my ($class, $client, $params) = @_;
	
	# $client is the client that is selected on the right side of the web interface!!!
	# We need the client identified by 'playerid'

	# Find player that fits the mac address supplied in $params->{'playerid'}
	my @playerItems = Slim::Player::Client::clients();
	foreach my $play (@playerItems) {
		if( $params->{'playerid'} eq $play->macaddress()) {
			$client = $play;
			last;
		}
	}
	if( !defined( $client)) {
		return $class->SUPER::handler($client, $params);
	}
	
	my @listRef = $classPlugin->getPlaylistAndPlayer( $client);

	# Get all available playlists
	$params->{'playlistList'} = ();
	foreach my $playlist ( @listRef) {
		$params->{'playlistList'}{$playlist->{'name'}} = $playlist->{'value'};
	}

	# Get selected playlist for all buttons
	my $tempPref = $prefs->client($client)->get('button');
	for( my $i = 0; $i < 10; $i++) {
		my $selPlaylist = $params->{'selPlaylist_' .$i};

		$log->debug( "*** QuickAccess: Playlists set on web: " . $i . ": " . $selPlaylist . "\n");

		# Upon loading the settings page, all 'selPlaylist_?' are empty!!!
		if( $selPlaylist ne "") {
			$tempPref->[$i] = $selPlaylist;
		}
	}
	$prefs->client($client)->set('button', $tempPref);

	# Fill selected playlist for all buttons
	$tempPref = $prefs->client($client)->get('button');
	for( my $i = 0; $i < 10; $i++) {
		$params->{'selPlaylist_' . $i} = $tempPref->[$i];
	}
	return $class->SUPER::handler($client, $params);
}

1;

__END__

