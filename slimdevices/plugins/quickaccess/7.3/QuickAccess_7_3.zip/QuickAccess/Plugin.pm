#	QuickAccess.pm
#
#	Current Maintainer: jasonholtzapple@yahoo.com
#	Creator: Felix Mueller <felix(dot)mueller(at)gwendesign(dot)com>
#
#	Copyright (c) 2003-2009
#
#	Based on: Several Plugins including KDFs bookmark plugin
#
#	----------------------------------------------------------------------
#	Function:
#
#	Quick access to preassigned playlists pressing and holding a button
#	New: Or the current playlist from another player
#
#	----------------------------------------------------------------------
#	Installation:
#
#	- Copy this file into the 'Plugins' directory
#	- Add three lines for each remote button to the file 'IR/custom.map'
#	- If the file is not present, add a new one to the 'IR' directory
#	  Example:
#		0		= dead
#		0.single	= numberScroll_0
#		0.hold		= modefunction_Plugins::QuickAccess::Plugin->startPlaylist_0
#		1		= dead
#		1.single	= numberScroll_1
#		1.hold		= modefunction_Plugins::QuickAccess::Plugin->startPlaylist_1
#	...
#		9		= dead
#		9.single	= numberScroll_9
#		9.hold		= modefunction_Plugins::QuickAccess::Plugin->startPlaylist_9
#
#	- Restart the server
#	- Select the 'custom.map' file in the Additional Player Settings (Web GUI)
#	- Assign playlists to the remote number buttons (0-9) in the plugin
#	- Press and hold a remote number button to play the assigned playlist
#	  even if Squeezebox / SLIMP3 was turned off.
#	----------------------------------------------------------------------
#	History:
#
#	2009/07/25 v7.3 - Fix sync w/7.3+
#	2007/05/02 v1.7 - New preference file
#	2007/04/01 v1.6 - INPUT.Choice, webpage, new logging
#	2007/01/02 v1.5 - SS 7.0 and new plugin api
#	2006/10/11 v1.4 - Fix for SS 6.5
#	2006/09/06 v1.3 - More changes for SS v6.5 beta
#	2006/07/05 v1.2 - Adapting to the latest SlimServer version 6.5
#	2005/09/13 v1.1 - Adapting to the latest SlimServer version 6.2beta
#			- Add global option to sync instead of passing playlists
#			  (Thanks Jason)
#	2005/07/09 v1.0 - Passing playlist from one player to other in db only
#	2005/07/04 v0.9 - Interim version for 6.1 beta
#	2005/02/08 v0.8 - SlimServer V6 ready
#	2004/12/23 v0.7 - iTunes playlists were broken
#	2004/07/21 v0.6 - Turn target player on explicitly
#	2004/07/10 v0.5 - Fix a problem with %20 in strings
#	2003/12/29 v0.4 - Playlist can also be from another player
#	2003/11/19 v0.3 - Adaption to SlimServer v5.0
#	2003/08/19 v0.2 - French translation by Nicolas Guillemain
#	2003/08/17 v0.1	- Initial version
#	----------------------------------------------------------------------
#       To do:
#
#	- It seems the playlist gets written to disk again, need to understand better
#	   so I can do it in db again
#	- showBriefly doesn't work if target player was turned off
#       - Multi language
#       - Clean up code
#
#	This program is free software; you can redistribute it and/or modify
#	it under the terms of the GNU General Public License as published by
#	the Free Software Foundation; either version 2 of the License, or
#	(at your option) any later version.
#
#	This program is distributed in the hope that it will be useful,
#	but WITHOUT ANY WARRANTY; without even the implied warranty of
#	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#	GNU General Public License for more details.
#
#	You should have received a copy of the GNU General Public License
#	along with this program; if not, write to the Free Software
#	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA
#	02111-1307 USA
#
package Plugins::QuickAccess::Plugin;
use base qw(Slim::Plugin::Base);
use strict;

use File::Spec::Functions;
use Scalar::Util qw(blessed);

use Slim::Player::Playlist;
use Slim::Player::Source;
use Slim::Player::Sync;
use Slim::Utils::Strings qw (string);
use Slim::Utils::Log;
use Slim::Utils::Prefs;

use Plugins::QuickAccess::Settings;

# ----------------------------------------------------------------------------
# Global variables
# ----------------------------------------------------------------------------

my $sync		= 0;	# 0 = no synch, 1 = sync
my @arrButtonChoice;
my %functions = ();

my $isNewStreaming = $::VERSION ge '7.3' ? 1 : 0;

# ----------------------------------------------------------------------------
# References to other classes
my $classPlugin = undef;

# ----------------------------------------------------------------------------
my $log = Slim::Utils::Log->addLogCategory({
	'category'     => 'plugin.quickaccess',
	'defaultLevel' => 'OFF',
	'description'  => 'PLUGIN_QUICKACCESS_MODULE_NAME',
});

# ----------------------------------------------------------------------------
my $prefs = preferences('plugin.quickaccess');

# ----------------------------------------------------------------------------
sub setMode {
	my $class = shift;
	my $client = shift;
	my $method = shift;
	
	if ($method eq 'pop') {
		Slim::Buttons::Common::popMode($client);
		return;
	}

	@arrButtonChoice = ();

	for( my $i = 0; $i < 10; $i++) {
		$arrButtonChoice[$i] = {
			'name' => $client->string( 'PLUGIN_QUICKACCESS_BUTTON') . " " . $i . ": " . $client->string('PLUGIN_QUICKACCESS_SELECT_PLAYLIST_OR_PLAYER'),
			'value' => $i,
		}
	}

	my @listRef = $classPlugin->getPlaylistAndPlayer( $client);
	
	# Use INPUT.Choice
	my %params = (
		'header'     => '{PLUGIN_QUICKACCESS_MODULE_NAME} {count}',
		'listRef'    => \@arrButtonChoice,
		'overlayRef' => sub { return [undef, $client->symbols('rightarrow')]},
		'modeName'   => 'QuickAccessButtonSelect',
		'onRight'    => sub {
			my ($client, $itemButton) = @_;


			# INPUT.Choice - chose playlist or player
			Slim::Buttons::Common::pushModeLeft( $client, 'INPUT.Choice', {
				'header'       => '{PLUGIN_QUICKACCESS_SELECT_PLAYLIST_OR_PLAYER} {count}',
				'listRef'      => \@listRef,
				'modeName'     => 'QuickAccessPlaylistSelect',
				'overlayRef'   => \&getSelectedPlaylistOverlay,
				'onRight'      => \&setSelectedPlaylist,
				'initialValue' => \&getSelectedPlaylistInitialValue,
				'itemButton'   => $itemButton,
			});
		},
	);
	Slim::Buttons::Common::pushMode( $client, 'INPUT.Choice', \%params);
}


# ----------------------------------------------------------------------------
sub getPlaylistAndPlayer {
	my $class = shift;
	my $client = shift;

	my @listRef = ();

	# Get all players except ourselfs
	my @playerItems = Slim::Player::Client::clients();
	foreach my $player (@playerItems) {
		if( $player->name() ne $client->name()) {
			push @listRef, {
					'name'     => "*Player: " . $player->name,
					'value'    => "***Player*** " . $player->name,
					}
		}
	}	

	# Get all playlists
	for my $playlist ( Slim::Schema->rs('Playlist')->getPlaylists) {
		push @listRef, { 
				'name' => $playlist->name,
				'value' => $playlist->url,
				};
	}

	return( @listRef);
}

# ----------------------------------------------------------------------------
sub getSelectedPlaylistOverlay {
	my ( $client, $playlist) = @_;

	my $button = $client->modeParam('itemButton');

	my $rv = '0';

	if( $prefs->client($client)->get('button')->[$button->{'value'}] eq $playlist->{'value'}) {
		$rv = '1';
	}
	return [undef, Slim::Buttons::Common::checkBoxOverlay( $client, $rv)];
}

# ----------------------------------------------------------------------------
sub setSelectedPlaylist {
	my ( $client, $playlist) = @_;

	my $button = $client->modeParam('itemButton');

	$log->debug( "*** QuickAccess: Button: " . $button->{'value'} . " Playlist or player: " . $playlist->{'value'} . "\n");

	my $tempPref = $prefs->client($client)->get('button');
	$tempPref->[$button->{'value'}] = $playlist->{'value'};
	$prefs->client($client)->set('button',$tempPref);
	$client->update;
}

# ----------------------------------------------------------------------------
sub getSelectedPlaylistInitialValue {
	my ( $client, $playlist) = @_;

	my $button = $client->modeParam('itemButton');

	my $pref = $prefs->client($client)->get('button')->[$button->{'value'}];

	if( $pref eq "") {
		$pref = "unmoeglich das genau zu treffen";	# Forces first item to show if none is selected
	}

	return $pref;
}

# ----------------------------------------------------------------------------
sub initPlugin {
	$classPlugin = shift;
	
	%functions = (
		'startPlaylist' => sub {
			my $client = shift;
			my $button = shift;
			my $digit = shift;

		# Get playlist or player name
		my $iEntry = $prefs->client($client)->get('button')->[$digit];

		$log->debug( "*** QuickAccess: Entry to start: $iEntry\n");
		# Check for player name
		if( $iEntry =~ /^\*\*\*Player\*\*\* /) {
			$iEntry =~ s/^\*\*\*Player\*\*\* //;
			my $playerName = $iEntry;
			if( defined $playerName) {
				my $sourcePlayer;

				# Get all player
				my @playerItems = ();
				@playerItems = Slim::Player::Client::clients();
				# Search for our player
				foreach my $cur (@playerItems) {
					if ($playerName eq $cur->name()) {
						$sourcePlayer = $cur;
						last;
					}
				}
				if( defined $sourcePlayer) {

					# Name of temp playlist
					my $title = "__followMePlaylist";

					# Save 'prefsaveshuffle'
					my $iOldPrefSaveShuffled = preferences('server')->get( "saveShuffled");
					$log->debug( "*** QuickAccess: Old save shuffle mode: $iOldPrefSaveShuffled\n");
					
					# Turn on 'prefsaveshuffle'
					preferences('server')->set( "saveShuffled", "1");
					$log->debug( "*** QuickAccess: Turn on save shuffled\n");

					# Source player: Save playlist to database
					$sourcePlayer->execute(["playlist", "save", $title]);
					$log->debug( "*** QuickAccess: Source player: Save current playlist\n");

					# Restore 'prefsaveshuffle'
					preferences('server')->set( "saveShuffled", $iOldPrefSaveShuffled);
					$log->debug( "*** QuickAccess: Restore old save shuffle mode.\n");

					# Source player: Save song index
					my $iSong = Slim::Player::Source::playingSongIndex( $sourcePlayer);
					$log->debug( "*** QuickAccess: Source player: Current song index: $iSong\n");

					# Source player: Save song position
					my $iTime = Slim::Player::Source::songTime($sourcePlayer);
					$log->debug( "*** QuickAccess: Source player: Current song time: $iTime\n");

					unless ($sync) {
						# Source player: Turn off
						$sourcePlayer->execute(["power", "0", ]);
						$log->debug( "*** QuickAccess: Source player: Turn off\n");
					}
					
					###############
					# Target player

					# Target player: Turn on
					$client->execute(["power", "1", ]);
					$log->debug( "*** QuickAccess: Target player: Turn on\n");
					
					# Target player: Get shuffle mode
					my $iOldShuffleMode = preferences('server')->client($client)->get( "shuffle");
					$log->debug( "*** QuickAccess: Target player: Old shuffle mode: $iOldShuffleMode\n");

					# Target player: Turn off shuffle
					preferences('server')->client($client)->set( "shuffle", "0");
					$log->debug( "*** QuickAccess: Target player: Turn shuffe off\n");
					
					unless ($sync) {
						# Target player: Block
						Slim::Buttons::Block::block(	$client,
										{
										'line1' => $client->string('PLUGIN_QUICKACCESS_MODULE_NAME'),
										'line2' => $client->string('PLUGIN_QUICKACCESS_PLAYING_FROM').$playerName,
										}
						);
						$log->debug( "*** QuickAccess: Target player: Enter block mode\n");
					}
					
					# Target player: Show message
					$client->showBriefly(
						{
							'line1' => $client->string('PLUGIN_QUICKACCESS_MODULE_NAME'),
							'line2' => $client->string('PLUGIN_QUICKACCESS_PLAYING_FROM').$playerName,
						},
						{
							'duration' => "2",
						}
				);
					$log->debug( "*** QuickAccess: Target player: Show message\n");

					if ($sync) {
						# Target player: sync
						if ($isNewStreaming) {
							$sourcePlayer->controller()->sync($client);
						} else {
							Slim::Player::Sync::sync($client, $sourcePlayer);
						}
						$log->debug( "*** QuickAccess: Target player: sync\n");
					} else {
						# Target player: Get saved playlist
###						my $ds = Slim::Music::Info::getCurrentDataStore();
###						my $url = "file://" . catfile( Slim::Utils::Prefs::get('playlistdir'), $title . '.m3u');
###						my $playlistObj = $ds->objectForUrl( $url);

						my $url = "file://" . catfile( preferences('server')->get('playlistdir'), $title . '.m3u');
						$log->debug( "*** QuickAccess: Target player: Playlist: " . $url . "\n");
						my $playlistObj = Slim::Schema->rs('Playlist')->objectForUrl({
							'url' => $url,
						});

						unless( $playlistObj) {
							$client->showBriefly(
								{
									'line1' => $client->string('PLUGIN_QUICKACCESS_MODULE_NAME'),
									'line2' => $client->string('PLUGIN_QUICKACCESS_PLAYLIST_NOT_AVAILABLE'),
								},
								{
									'duration' => "2",
								}
							);
							# Target player: unblock
							Slim::Buttons::Block::unblock( $client);
							$log->debug( "*** QuickAccess: Target player: Unblock\n");

							return;
						}
						$client->execute(["playlist","loadtracks","playlist=".$playlistObj->id()], \&playlistLoadDone, [$client,$iSong,$iTime,$iOldShuffleMode]);
						$log->debug( "*** QuickAccess: Target player: Load saved playlist\n");
					}
				}
				else {
					# Show error message
					$client->showBriefly(
						{
							'line1' => $client->string( 'PLUGIN_QUICKACCESS_MODULE_NAME'),
							'line2' => $client->string( 'PLUGIN_QUICKACCESS_PLAYLIST_NOT_AVAILABLE'),
						},
						{
							'duration' => "2",
						}
					);
				}
			}
		}
		# Load playlist
		elsif( defined ( $prefs->client($client)->get('button')->[$digit])) {

			$client->execute(["stop"]);
			if ($sync) {
				if ($isNewStreaming) {
					$client->controller()->unsync($client);
				} else {
					Slim::Player::Sync::unsync($client);
				}
			}

			my $playlistURL = $prefs->client($client)->get('button')->[$digit];
			my $playlistObj = Slim::Schema->rs('Playlist')->objectForUrl({
				'url' => $playlistURL,
			});

			if( blessed( $playlistObj) && $playlistObj->can( 'id')) {
				$client->showBriefly(
						{
						'line1' => $client->string( 'PLUGIN_QUICKACCESS_MODULE_NAME'),
						'line2' => $client->string( 'PLUGIN_QUICKACCESS_PLAYING_FROM') . $playlistObj->title,
						},
						{
						'duration' => "2",
						}
				);
				$client->execute(["playlist", "playtracks", "playlist=".$playlistObj->id]);
			}
		} else {
			$client->showBriefly(
						{
						'line1' => $client->string( 'PLUGIN_QUICKACCESS_MODULE_NAME'),
						'line2' => $client->string( 'PLUGIN_QUICKACCESS_PLAYLIST_NOT_AVAILABLE'),
						},
						{
						'duration' => "3",
						}
			);
		}
	},
	);

	# Initialize settings classes
	my $classSetting = Plugins::QuickAccess::Settings->new( $classPlugin);

	$classPlugin->SUPER::initPlugin();
}

# ----------------------------------------------------------------------------
sub shutdownPlugin {

}

# ----------------------------------------------------------------------------
sub getFunctions {
	return \%functions;
}

# ----------------------------------------------------------------------------
sub playlistLoadDone {
	my $client = shift;
	my $iSong = shift;
	my $iTime = shift;
	my $iOldShuffleMode = shift;

	# Target player: unblock
	Slim::Buttons::Block::unblock($client);
	$log->debug( "*** QuickAccess: Target player: Unblock\n");
	
	# Target player: Set song index
	Slim::Player::Source::jumpto( $client, $iSong);
	$log->debug( "*** QuickAccess: Target player: Set song index: $iSong\n");

	# Target player: Set song time
	Slim::Player::Source::gototime($client,$iTime,1);
	$log->debug( "*** QuickAccess: Target player: Set song time: $iTime\n");

	# Target player: Set old shuffle mode
	preferences('server')->client($client)->set( "shuffle", $iOldShuffleMode);
	$log->debug( "*** QuickAccess: Target player: Set old shuffle mode: $iOldShuffleMode\n");
}

# ----------------------------------------------------------------------------
sub getDisplayName() {
	return 'PLUGIN_QUICKACCESS_MODULE_NAME';
}

1;

__END__

